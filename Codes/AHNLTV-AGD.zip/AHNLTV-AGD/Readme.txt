Author: 

Chao Ren
Ph.D,
School of Electronics and Information Engineering, 
SiChuan University, Chengdu, China.   


The code is associated with the following paper:

Chao Ren, Xiaohai He, and Truong Q. Nguyen.,"Single Image Super-Resolution via Adaptive High-Dimensional Non-Local Total Variation and Adaptive Geometric Feature", IEEE Trans. on Image Processing, vol. 26, no. 1, pp. 90-106, Jan. 2017.  

Please cite this paper if you use this code. 

For further information, please contact: chaoren881125@163.com

Homepage: https://sites.google.com/site/chaorenhomepage/