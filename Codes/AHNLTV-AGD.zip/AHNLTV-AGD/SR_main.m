% ===========================================================================
% AHNLTV-AGD for single image super-resolution, Version 1.0                 %
% Copyright(c) 2017 Chao Ren, Xiaohai He, and Truong Q. Nguyen              %
% All Rights Reserved.                                                      %
%                                                                           %
%----------------------------------------------------------------------------
%                                                                           %
% This is an implementation of the algorithm for image super-resolution     %
%                                                                           %
% Please cite the following paper if you use this code:                     %
%                                                                           %
% Chao Ren, Xiaohai He, and Truong Q. Nguyen.,"Single Image Super-Resolution%
% via Adaptive High-Dimensional Non-Local Total Variation and Adaptive      %
% Geometric Feature", IEEE Trans. on Image Processing, vol. 26, no. 1,      %
% pp. 90-106, Jan. 2017.                                                    %
%                                                                           %
%----------------------------------------------------------------------------
%                                                                           %
% Any further questions, please contact Chao Ren via: chaoren881125@163.com %
% Homepage: https://sites.google.com/site/chaorenhomepage/                  %
% School of Electronics and Information Engineering of SiChuan University   %
%----------------------------------------------------------------------------
clear all;
close all;
clc

p = pwd;
addpath(genpath(fullfile(p, '/TFOCS')));
addpath(genpath(fullfile(p, '/Output')))
addpath(genpath(fullfile(p, '/Input')))
addpath(genpath(fullfile(p, '/Output')))
addpath(genpath(fullfile(p, '/Code')))

%----------------------------------------------------------------------------
%CONFIGURATIONS OF EXPERIMENTS-----------------------------------------------
scale = 3; %Downsampling factor
%Blur kernel
psf = fspecial('gaussian',7,1.5); %Gaussian blur kernel
% Blur_par=9; psf= ones(Blur_par)/(Blur_par*Blur_par); %Uniform blur kernel
%Noise level
nSig = 0;

%----------------------------------------------------------------------------
%PARAMETERS------------------------------------------------------------------
par = AHNLTV_AGD_SR_Par;

%----------------------------------------------------------------------------
%OTHERS----------------------------------------------------------------------
input_dir = 'Input';
pattern = '*.tif'; 
filenames = glob(input_dir, pattern);

% for i=1:numel(filenames)
for image_num=6:6
    f = filenames{image_num};
    orignal_I=imread(f);

    [PSNR_AHNLTV_AGD(image_num), SSIM_AHNLTV_AGD(image_num), PSNR_BIC(image_num), SSIM_BIC(image_num), TIME_AHNLTV_AGD(image_num)]=AHNLTV_AGD_SR(orignal_I, scale, psf, nSig, image_num, par)

    save PSNR_AHNLTV_AGD.mat PSNR_AHNLTV_AGD filenames
    save SSIM_AHNLTV_AGD.mat SSIM_AHNLTV_AGD filenames
    save TIME_AHNLTV_AGD.mat TIME_AHNLTV_AGD filenames

    save PSNR_BIC.mat PSNR_BIC filenames
    save SSIM_BIC.mat SSIM_BIC filenames
end