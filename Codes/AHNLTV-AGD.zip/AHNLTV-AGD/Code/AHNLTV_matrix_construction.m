% ===========================================================================
% AHNLTV-AGD for single image super-resolution, Version 1.0                 %
% Copyright(c) 2017 Chao Ren, Xiaohai He, and Truong Q. Nguyen              %
% All Rights Reserved.                                                      %
%                                                                           %
%----------------------------------------------------------------------------
%                                                                           %
% This is an implementation of the algorithm for image super-resolution     %
%                                                                           %
% Please cite the following paper if you use this code:                     %
%                                                                           %
% Chao Ren, Xiaohai He, and Truong Q. Nguyen.,"Single Image Super-Resolution%
% via Adaptive High-Dimensional Non-Local Total Variation and Adaptive      %
% Geometric Feature", IEEE Trans. on                                        %
% Image Processing, vol. 26, no. 1, pp. 90-106, Jan. 2017.                  %
%                                                                           %
%----------------------------------------------------------------------------
%                                                                           %
% Any further questions, please contact Chao Ren via: chaoren881125@163.com %
% Homepage: https://sites.google.com/site/chaorenhomepage/                  %
% School of Electronics and Information Engineering of SiChuan University   %
%----------------------------------------------------------------------------
function [AHNLTV_matrix, R_D]=AHNLTV_matrix_construction(Ori_image,Patch_size,SS,SN,h,alpha,ratio)

[WM, WN]=size(Ori_image);
cnt=1;
N_non_smooth=(WM-SS+1)*(WN-SS+1);

hh=zeros(1,N_non_smooth*SN*2*Patch_size^2);
ll=zeros(1,N_non_smooth*SN*2*Patch_size^2);
vv=zeros(1,N_non_smooth*SN*2*Patch_size^2);

[x, y, Count, Ave_f, R_D]=Search_similar_patches(Ori_image, Patch_size, SS, SN, ratio);

Count=Count./(alpha+Count);

total_num=0;

for i=(SS-1)/2+1:1:-(SS-1)/2+WM
    if (i-ceil(i/50)*50)==0    
        fprintf([num2str(i),'\n']);       
    end
    for j=(SS-1)/2+1:1:-(SS-1)/2+WN
        SSN=R_D(i,j);
        Si=x(i,j,1:SSN);
        Sj=y(i,j,1:SSN);  
        Si=Si(:)';
        Sj=Sj(:)';
        W_center=Ave_f((Sj-1)*WM+Si);% Similar pixels
        uk=Ave_f(i,j);% Center pixel
        weightn=exp(-(W_center'-uk).^2./(2* h^2));% Weights
        c=Count(i,j,1:SSN);
        c=c(:);
        tt=(j-1)*WM+i;
        ll(cnt:cnt+SSN-1)=(Sj-1)*WM+Si;
        ll(cnt+SSN:cnt+2*SSN-1)=tt;
        temp_vv=sqrt(weightn(:).*c);
        vv(cnt:cnt+2*SSN-1)=[-temp_vv;temp_vv];
        hh_num=total_num+[1:SSN];
        hh(cnt:cnt+2*SSN-1)=[hh_num, hh_num];
        cnt=cnt+2*SSN;      
        total_num=total_num+SSN;
    end
end

clear x y Count Ave_f

hh(ll==0)=[];
vv(ll==0)=[];
ll(ll==0)=[];

AHNLTV_matrix=sparse(hh,ll,vv,total_num,WM*WN);