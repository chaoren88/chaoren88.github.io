function [PSNR_HR,SSIM_HR,  PSNR_bic, SSIM_bic, Running_time]=AHNLTV_AGD_SR(orignal_I, scale, psf, nSig, image_num, par)
    
output_dir = 'Output';
[h, l, c]=size(orignal_I);

%--------------------------------------------------------------------------
%GENERATE THE LR IMAGE-----------------------------------------------------
size_increase1=[scale*ceil(size(orignal_I(:,:,1))/scale)-size(orignal_I(:,:,1)) 0];
orignal_I=double(orignal_I);
ori=padarray(orignal_I,size_increase1,'symmetric','post');

%Blurring
lr_image = Blur('fwd', ori, psf);

%Downsampling
lr_image = lr_image(1:scale:end,1:scale:end,:);   

%Add noise
seed  =  0;
randn( 'state', seed );
noise =  randn( size(lr_image) );
lr_image = lr_image + nSig*noise;

imwrite(uint8(lr_image),strcat(output_dir,'\LR_im',num2str(image_num),'.png'),'png');

%Convert to YCBCR space
lr_image=rgb2ycbcr(uint8(lr_image));
lr_image=double(lr_image);
y=lr_image(:,:,1);
y_cb=lr_image(:,:,2);
y_cr=lr_image(:,:,3);

%--------------------------------------------------------------------------
%RECONSTRUCTION------------------------------------------------------------
size_increase2=[0 0];
if (size(y,1)-2*floor(size(y,1)/2))==0
    size_increase2(1,1)=0;
else
    size_increase2(1,1)=1;
end
if (size(y,2)-2*floor(size(y,2)/2))==0
    size_increase2(1,2)=0;
else
    size_increase2(1,2)=1;
end
image=padarray(y,size_increase2,'symmetric','post');

tic

hr_ytemp = Superresolution(image, scale, psf, par);

Running_time=toc;

%--------------------------------------------------------------------------
%QUALITY EVALUATIONS-------------------------------------------------------
hr_y=uint8(hr_ytemp(1:end-scale*size_increase2(1),1:end-scale*size_increase2(2)));

orignal_I=rgb2ycbcr(uint8(orignal_I));
%Calculation of PSNR&SSIM
PSNR_HR = cal_psnr(hr_y(1:end-size_increase1(1),...
    1:end-size_increase1(2)),orignal_I(:,:,1),par.edge,par.edge);
SSIM_HR  =  cal_ssim( hr_y(1:end-size_increase1(1),...
    1:end-size_increase1(2)),orignal_I(:,:,1),par.edge,par.edge );

str_out=['\nPSNR_HR= ' ,num2str(PSNR_HR) ,'dB.\n'];
fprintf(str_out); 
str_out=['SSIM_HR= ' ,num2str(SSIM_HR) ,'.\n'];
fprintf(str_out);

%Merge channels
hr_temp(:,:,1)=hr_y;
hr_temp(:,:,2)=bicubic_correspondig(y_cb,scale);
hr_temp(:,:,3)=bicubic_correspondig(y_cr,scale);
hr_temp=ycbcr2rgb(uint8(hr_temp));

HR=hr_temp(1:end-size_increase1(1),1:end-size_increase1(2),:);
HR=uint8(HR);

imwrite(HR,strcat(output_dir,'\AHNLTV_AGD_HR_im',num2str(image_num),'.png'));

sprintf('bic');
bic_y=bicubic_correspondig(y,scale); 

PSNR_bic = cal_psnr(bic_y(1:h,1:l),orignal_I(:,:,1),par.edge,par.edge);
SSIM_bic  =  cal_ssim( bic_y(1:h,1:l),orignal_I(:,:,1),par.edge,par.edge );

str_out=['PSNR_BIC= ' ,num2str(PSNR_bic) ,'dB.\n'];
fprintf(str_out); 
str_out=['SSIM_BIC= ' ,num2str(SSIM_bic) ,'.\n'];
fprintf(str_out); 

I_bic(:,:,1)=bic_y;
I_bic(:,:,2)=bicubic_correspondig(y_cb,scale);
I_bic(:,:,3)=bicubic_correspondig(y_cr,scale);
I_bic=ycbcr2rgb(uint8(I_bic));

imwrite(I_bic(1:h,1:l,:),strcat(output_dir,'\Bicubic_im',num2str(image_num),'.png'));