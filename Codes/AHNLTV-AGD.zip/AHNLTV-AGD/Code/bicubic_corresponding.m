%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Chao Ren 2014 7 18                                                      %
% version 2.0                                                             %
% Note: bicubic interpolation                                             %
%                                                                         %
% Email: chaoren881125@gmail.com;  chaoren881125@163.com                  %
% School of Electronics and Information Engineering of SiChuan University %
% Homepage; https://sites.google.com/site/chaorenhomepage/                %
%                                                                         %
% Chao Ren, Xiaohai He, and Truong Q. Nguyen.,"Single Image Super-        %
% Resolution via Adaptive High-Dimensional Non-Local Total Variation and  %
% Adaptive Geometric Feature", IEEE Trans. on Image Processing, vol. 26,  %
% no. 1, pp. 90-106, Jan. 2017.                                           %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  

function g=bicubic_corresponding(f,r)

%Interpolate border pixel(right & down) values
y_temp=padarray(f,[1 1],'symmetric','post');
%The low resolution image coordinates x,y
x=1:size(y_temp,1);
y=1:size(y_temp,2);
[X1,Y1]=meshgrid(y,x);
%The high resolution image coordinates x,y
X2=1:1/r:size(y_temp,1);
Y2=1:1/r:size(y_temp,2);
[X3,Y3]=meshgrid(Y2,X2);
%bicubic interpolation
bic_y_temp = interp2(X1,Y1,y_temp,X3,Y3,'cubic'); 
%Remove excess column
g=bic_y_temp(1:end-1,1:end-1);   