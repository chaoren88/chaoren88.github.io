function  par  =  AHNLTV_AGD_SR_Par

par.edge=5; %The width of the border pixels in quality evaluations

%Parameters for AHNLTV
par.Patch_size=7; %Patch size in AHNLTV
par.Searchwin_size=13; %Search area size in AHNLTV
par.Similar_N=10; %The number of non-local similar patches
par.h=24; %The global filter parameter in AHNLTV
par.alpha=par.Patch_size^2;
par.ratio=1/(par.Similar_N+1);

%Parameters for AGD
par.sigma1=90;
par.sigma2=13;
par.sigma3=13;
par.sigma4=3;
par.P=2;
par.thres1=0.7;
par.thres2=0.5;

par.To=3; 
par.Ti=15;  

% % scale=3, nSig=0, Blur_kernel=fspecial('gaussian',7,1.5);
par.lam_ahnltv=0.0050;
par.lam_agd=0.00030;

par.mu=par.lam_ahnltv/100;

