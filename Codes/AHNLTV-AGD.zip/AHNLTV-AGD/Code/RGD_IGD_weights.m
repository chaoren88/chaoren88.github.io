% ===========================================================================
% AHNLTV-AGD for single image super-resolution, Version 1.0                 %
% Copyright(c) 2017 Chao Ren, Xiaohai He, and Truong Q. Nguyen              %
% All Rights Reserved.                                                      %
%                                                                           %
%----------------------------------------------------------------------------
%                                                                           %
% This is an implementation of the algorithm for image super-resolution     %
%                                                                           %
% Please cite the following paper if you use this code:                     %
%                                                                           %
% Chao Ren, Xiaohai He, and Truong Q. Nguyen.,"Single Image Super-Resolution%
% via Adaptive High-Dimensional Non-Local Total Variation and Adaptive      %
% Geometric Feature", IEEE Trans. on                                        %
% Image Processing, vol. 26, no. 1, pp. 90-106, Jan. 2017.                  %
%                                                                           %
%----------------------------------------------------------------------------
%                                                                           %
% Any further questions, please contact Chao Ren via: chaoren881125@163.com %
% Homepage: https://sites.google.com/site/chaorenhomepage/                  %
% School of Electronics and Information Engineering of SiChuan University   %
%----------------------------------------------------------------------------
function [W_RGD, W_IGD]=RGD_IGD_weights(HR, par, E_temp)

% The probabilities of two directional patterns    
fpad = padarray(HR, [2 2], 'symmetric');
f_1=fpad(1:end-4,1:end-4);
f_2=fpad(1:end-4,3:end-2);
f_3=fpad(1:end-4,5:end);
f_4=fpad(2:end-3,2:end-3);
f_5=fpad(2:end-3,3:end-2);
f_6=fpad(2:end-3,4:end-1);
f_7=fpad(3:end-2,1:end-4);
f_8=fpad(3:end-2,2:end-3);
f_9=fpad(3:end-2,3:end-2);
f_10=fpad(3:end-2,4:end-1);
f_11=fpad(3:end-2,5:end);
f_12=fpad(4:end-1,2:end-3);
f_13=fpad(4:end-1,3:end-2);
f_14=fpad(4:end-1,4:end-1);
f_15=fpad(5:end,1:end-4);
f_16=fpad(5:end,3:end-2);
f_17=fpad(5:end,5:end);

mean_0=(f_7+f_8+f_9+f_10+f_11)/5;
mean_45=(f_3+f_6+f_9+f_12+f_15)/5;
mean_90=(f_2+f_5+f_9+f_13+f_16)/5;
mean_135=(f_1+f_4+f_9+f_14+f_17)/5;

var_0=((f_7-mean_0).^2+(f_8-mean_0).^2+(f_9-mean_0).^2+(f_10-mean_0).^2+(f_11-mean_0).^2)/5;
var_45=((f_3-mean_45).^2+(f_6-mean_45).^2+(f_9-mean_45).^2+(f_12-mean_45).^2+(f_15-mean_45).^2)/5;
var_90=((f_2-mean_90).^2+(f_5-mean_90).^2+(f_9-mean_90).^2+(f_13-mean_90).^2+(f_16-mean_90).^2)/5;
var_135=((f_1-mean_135).^2+(f_4-mean_135).^2+(f_9-mean_135).^2+(f_14-mean_135).^2+(f_17-mean_135).^2)/5;

clear f_1 f_4 f_9 f_14 f_17 f_2 f_5 f_9 f_13 f_16 f_3 f_6 f_9 f_12 f_15 f_7 f_8 f_9 f_10 f_11 mean_0 mean_45 mean_90 mean_135

W_RGD2=min(sqrt(var_0),sqrt(var_90))./(min(sqrt(var_0),sqrt(var_90))+min(sqrt(var_45),sqrt(var_135))+eps);
W_RGD2(E_temp<par.thres1)=0.5;
W_IGD2=1-W_RGD2;

clear E_temp var_0 var_45 var_90 var_135

W_RGD=sqrt(W_RGD2);
W_IGD=sqrt(W_IGD2);