% ===========================================================================
% AHNLTV-AGD for single image super-resolution, Version 1.0                 %
% Copyright(c) 2017 Chao Ren, Xiaohai He, and Truong Q. Nguyen              %
% All Rights Reserved.                                                      %
%                                                                           %
%----------------------------------------------------------------------------
%                                                                           %
% This is an implementation of the algorithm for image super-resolution     %
%                                                                           %
% Please cite the following paper if you use this code:                     %
%                                                                           %
% Chao Ren, Xiaohai He, and Truong Q. Nguyen.,"Single Image Super-Resolution%
% via Adaptive High-Dimensional Non-Local Total Variation and Adaptive      %
% Geometric Feature", IEEE Trans. on                                        %
% Image Processing, vol. 26, no. 1, pp. 90-106, Jan. 2017.                  %
%                                                                           %
%----------------------------------------------------------------------------
%                                                                           %
% Any further questions, please contact Chao Ren via: chaoren881125@163.com %
% Homepage: https://sites.google.com/site/chaorenhomepage/                  %
% School of Electronics and Information Engineering of SiChuan University   %
%----------------------------------------------------------------------------
function HR=Superresolution(LR, scale, psf, par)

if scale==1
    size_increase=[30 30];
elseif scale==2
    size_increase=[15 15];
elseif scale==3
    size_increase=[10 10];
elseif scale==4
    size_increase=[8 8];
end

LR=padarray(LR,size_increase,'symmetric');%Enlarge LR to deal with border pixels

HR=bicubic_correspondig(double(LR),scale);
HR=double(HR);

[M,N]=size(LR);
M=M*scale;
N=N*scale;

par.LR=LR;
par.psf=psf;
DH = Set_blur_matrix(par, scale);  

for iter=1:par.To

    % Calculate the local nonsmoothness
    E_temp=zeros(size(HR));
    E=zeros(size(HR));
    fpad=zeros(M+2*par.P,N+2*par.P);
    fpad(:,:) = padarray(HR(:,:), [par.P par.P], 'symmetric');

    for l=-par.P:par.P
      for m=-par.P:par.P
        % Shift HR image
        fshift = fpad(1+par.P-l:end-par.P-l, 1+par.P-m:end-par.P-m);

        E_temp=E_temp+abs((HR-fshift)/255);
      end
    end
    % Local nonsmoothness
    E_temp=E_temp./(1+(E_temp));
    E(E_temp>=par.thres2)=1;
    
    clear fpad fshift
       
    %----------------------------------------------------------------------------
    % AHNLTV prior---------------------------------------------------------------    
    str_out=['\n','Begin to construct the AHNLTV prior ',num2str(iter),'\n'];
    fprintf(str_out);
    fprintf(['*****************************************************************\n']);

    [W_ahnltv, Count]=AHNLTV_matrix_construction(HR,par.Patch_size,par.Searchwin_size,par.Similar_N,par.h,par.alpha,par.ratio);

    str_out=['The AHNLTV prior is constructed ',num2str(iter),'\n'];
    fprintf(str_out);  
    fprintf(['*****************************************************************\n\n']);
    
    %----------------------------------------------------------------------------
    % AGD prior------------------------------------------------------------------  
    str_out=['Begin to construct the AGD prior ',num2str(iter),'\n'];
    fprintf(str_out); 
    fprintf(['*****************************************************************\n\n']);
    
    [W_RGD, W_IGD]=RGD_IGD_weights(HR, par, E_temp);

    [W_lu, img, mask]=RGD(HR,'lu',E,par.sigma1,par.sigma2,par.sigma3,par.sigma4,W_RGD);
    [W_ru, img, mask]=RGD(HR,'ru',E,par.sigma1,par.sigma2,par.sigma3,par.sigma4,W_RGD);
    [W_ld, img, mask]=RGD(HR,'ld',E,par.sigma1,par.sigma2,par.sigma3,par.sigma4,W_RGD);
    [W_rd, img, mask]=RGD(HR,'rd',E,par.sigma1,par.sigma2,par.sigma3,par.sigma4,W_RGD);
    [W_1, img, mask]=IGD(HR,'patern1',E,par.sigma1,par.sigma2,par.sigma3,par.sigma4,W_IGD);
    [W_2, img, mask]=IGD(HR,'patern2',E,par.sigma1,par.sigma2,par.sigma3,par.sigma4,W_IGD);

    W_AGD1=(W_lu+W_ru+W_ld+W_rd);
    W_AGD2=(W_1+W_2);

    clear W_lu W_ru W_ld W_rd W_1 W_2

    hhh=zeros(1,size(W_RGD,1)*size(W_RGD,2));
    lll=zeros(1,size(W_RGD,1)*size(W_RGD,2));
    vvv_o=zeros(1,size(W_RGD,1)*size(W_RGD,2));
    vvv_n=zeros(1,size(W_RGD,1)*size(W_RGD,2));
    cnt=1;
    for iii=1:size(W_RGD,1)
        for jjj=1:size(W_RGD,2)
            hhh(cnt)=(jjj-1)*size(W_RGD,1)+iii;
            lll(cnt)=hhh(cnt);
            vvv_o(cnt)=W_RGD(iii,jjj);
            vvv_n(cnt)=W_IGD(iii,jjj);
            cnt=cnt+1;
        end
    end
    S_W_RGD=sparse(hhh,lll,vvv_o,size(W_RGD,1)*size(W_RGD,2),size(W_RGD,1)*size(W_RGD,2));
    S_W_IGD=sparse(hhh,lll,vvv_n,size(W_IGD,1)*size(W_IGD,2),size(W_IGD,1)*size(W_IGD,2));
    G_AGD1=(S_W_RGD-W_AGD1);
    G_AGD2=(S_W_IGD-W_AGD2);
    G_AGD=sqrt(par.lam_agd)*[G_AGD1; G_AGD2];
    
    str_out=['The AGD prior is constructed ',num2str(iter),'\n'];
    fprintf(str_out); 
    fprintf(['*****************************************************************\n\n']);
    
    y_hat=[LR(:);zeros(size(G_AGD,1),1)];
    W_hat=[DH;G_AGD];

    clear hhh lll vvv_o vvv_n S_W_RGD S_W_IGD W_AGD1 W_AGD2 W_RGD W_IGD

    %----------------------------------------------------------------------------
    % SBI------------------------------------------------------------------------     
    v=zeros(size(W_ahnltv,1),1);
    b=zeros(size(W_ahnltv,1),1);    

    for Inloop = 1:par.Ti
        constant_b=[y_hat;(v-b)*sqrt(par.mu)];
        constant_A=[W_hat;sqrt(par.mu)*W_ahnltv];
        HR=tfocs(smooth_quad, { constant_A, -constant_b},0,HR(:));
        v=GSO(HR,b,W_ahnltv,2*par.mu/par.lam_ahnltv,Count,M,N,par.Searchwin_size);      
        b = b + (W_ahnltv*HR - v);
    end    

    HR=reshape(HR,[M, N]);
    clear W_ahnltv constant_A 
end    

HR=HR(1+scale*size_increase(1):end-scale*size_increase(1),1+scale*size_increase(2):end-scale*size_increase(2));